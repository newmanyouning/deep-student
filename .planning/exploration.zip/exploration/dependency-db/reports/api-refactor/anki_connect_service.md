# API 重构: Anki Connect Service

**日期**: 2026-05-29 | **命令数**: 1 | **对应诊断**: round-20~26

---

## 当前问题

1 个命令

## 当前参数模式

| 参数类型 | 出现次数 |
|---------|--------|

## 当前返回类型

| 返回类型 | 出现次数 |
|---------|--------|
| `bool` | 1 |

## 命令清单与变更

| 当前命令 | 改为 | 参数变更 | 返回变更 |
|---------|------|---------|--------|
| `check_anki_connect_availability` | *(保持)* | — | Result<T, AppError> |

## 改进操作

合并到 cmd::anki_connect

## 统一错误类型

`AppError` — 替换当前使用的 `String` / `AppError`

---
*此报告由 deps.db 数据自动生成，对应模块原始数据见 `_data/anki_connect_service.json`*
