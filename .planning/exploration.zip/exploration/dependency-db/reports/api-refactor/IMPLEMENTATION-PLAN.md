# API 重构实施计划

**日期**: 2026-05-29
**原则**: 最小改动、向后兼容、单文件修改、逐步提交

---

## 实施策略

由于 Rust 模块间引用复杂（移动文件需要更新所有 `use` 路径），采用**逻辑拆分 + 物理逐步迁移**策略：

| 阶段 | 改动 | 风险 |
|------|------|------|
| 1 | 添加错误类型（新增代码，不修改现有逻辑） | 无 |
| 2 | 封装 MemoryContext（减少 State 参数） | 低 |
| 3 | 重命名 lib.rs 注册路径（逻辑拆分） | 中 |
| 4 | 物理移动文件 | 高（需全量测试） |

---

## 阶段 1: 添加统一错误类型

### 1.1 Todo/Pomodoro 错误类型

**文件**: `src-tauri/src/vfs/todo_handlers.rs`

当前 20 个 Todo 命令 + 5 个 Pomodoro 命令全部返回 `Result<T, String>`。

**改动**: 在文件顶部添加 `TodoError` 和 `PomodoroError` 枚举，替换 `String` 错误类型。

### 1.2 Memory 错误类型

**文件**: `src-tauri/src/memory/` (新建 `error.rs`)

当前 27 个 Memory 命令返回 `Result<T, String>`。

**改动**: 添加 `MemoryError` 枚举 + `MemoryResult<T>` 别名。

### 1.3 Chat V2 错误类型

**文件**: `src-tauri/src/chat_v2/` (新建 `error.rs`)

当前 78 个 Chat V2 命令返回 `Result<T, String>`。

**改动**: 添加 `ChatV2Error` 枚举。

### 1.4 Essay Grading 错误类型

**文件**: `src-tauri/src/essay_grading/` (新建 `error.rs`)

当前 20 个命令未用 Result 包裹。

**改动**: 添加 `EssayGradingError`，包装返回值。

---

## 阶段 2: MemoryContext 封装

### 2.1 创建 MemoryContext

**文件**: `src-tauri/src/memory/context.rs` (新建)

将每个 Memory 命令重复的 3 个 State 参数封装：

```rust
pub struct MemoryContext {
    pub vfs_db: Arc<VfsDatabase>,
    pub lance_store: Arc<VfsLanceStore>,
    pub llm_manager: Arc<LLMManager>,
}
```

---

## 阶段 3: 逻辑拆分（lib.rs 注册路径重命名）

### 3.1 Todo/Pomodoro 独立注册

当前:
```rust
,crate::vfs::todo_handlers::todo_create_list
```
改为:
```rust
// ── Todo 命令 ──
,crate::vfs::todo_handlers::todo_create_list  // 路径不变，注释标记
// ── Pomodoro 命令 ──
,crate::vfs::todo_handlers::pomodoro_create_record  // 路径不变
```

### 3.2 Voice Input 独立注册

voice_input 已有独立模块 `crate::voice_input`，但命令注册混在 main block 中。

---

## 本次执行: 阶段 1 全部 + 阶段 2 部分

实际修改 3 个文件:
1. `src-tauri/src/vfs/todo_handlers.rs` — 添加 TodoError + PomodoroError
2. `src-tauri/src/memory/error.rs` — 新建 MemoryError
3. `src-tauri/src/chat_v2/error.rs` — 新建 ChatV2Error
4. `src-tauri/src/essay_grading/error.rs` — 新建 EssayGradingError
